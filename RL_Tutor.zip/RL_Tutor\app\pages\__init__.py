"""
Page registry. The order below IS the sidebar order, and page numbers are
assigned from it automatically -- so reordering this list renumbers everything
and no TITLE string ever has to be edited.

The sequence is deliberately concrete-before-abstract:

    1-3   the environment, felt by hand before it is named
    4-5   what you get paid, and how a whole episode becomes one number
    6-7   the thing we search for (a policy), then the formal framework (MDP)
    8-11  how to measure how good a square is
    12-16 compute the perfect policy, given that we know the ice
    17-19 learn it WITHOUT knowing the ice -- what a real robot must do
    20-25 the surrounding ideas
"""

from .dp_pages import (
    CompareDPPage,
    PolicyEvalPage,
    PolicyImprovePage,
    PolicyIterationPage,
    ValueIterationPage,
)
from .extras import BanditPage, ConvergencePage, HyperPage, ModelPage
from .foundations import MDPPage, PolicyPage
from .frozenlake import FrozenLakePage, TransitionsPage
from .intro import ReturnPage, RewardPage, WhatIsRLPage
from .lab import AdamPage, CodeLabPage
from .mc_pages import MCControlPage, MCIntroPage, MCPredictionPage
from .values import ActionValuePage, BellmanPage, StateValuePage, VvsQPage

PAGE_CLASSES = [
    # ---- Start Here: the environment, then the vocabulary ----------------
    WhatIsRLPage,          # 1   play it yourself
    FrozenLakePage,        # 2   the board
    TransitionsPage,       # 3   the slippery ice, with real probabilities
    RewardPage,            # 4   what the lake pays you
    ReturnPage,            # 5   a list of rewards -> one number, via gamma
    PolicyPage,            # 6   the thing we are searching for
    MDPPage,               # 7   all five pieces, formally named
    # ---- Value Functions: how good is a square? ---------------------------
    StateValuePage,        # 8
    ActionValuePage,       # 9
    VvsQPage,              # 10
    BellmanPage,           # 11
    # ---- Dynamic Programming: solve it, knowing the ice -------------------
    PolicyEvalPage,        # 12
    PolicyImprovePage,     # 13
    PolicyIterationPage,   # 14
    ValueIterationPage,    # 15
    CompareDPPage,         # 16
    # ---- Monte Carlo: learn it, NOT knowing the ice -----------------------
    MCIntroPage,           # 17
    MCPredictionPage,      # 18
    MCControlPage,         # 19
    # ---- Beyond -----------------------------------------------------------
    BanditPage,            # 20
    ModelPage,             # 21
    HyperPage,             # 22
    ConvergencePage,       # 23
    CodeLabPage,           # 24
    AdamPage,              # 25
]

# Stamp each class with its 1-based position. Page headers and the sidebar read
# this, so the numbers can never drift out of sync with the order above.
for _i, _cls in enumerate(PAGE_CLASSES, start=1):
    _cls.NUM = _i
